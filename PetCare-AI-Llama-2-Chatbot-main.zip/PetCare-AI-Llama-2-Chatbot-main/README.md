# PetCare-AI-Chatbot
LLM-based Chatbot for PetCare. The app is built on open source stack and useful for Vet Doctors, Pet Lovers, etc. Supercharge your PetCare conversations with our lightning-fast AI chatbot powered by Llama 2.
